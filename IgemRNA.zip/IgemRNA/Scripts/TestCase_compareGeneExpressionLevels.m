sourceDataSet = 'SRR8994357_WT';
targetDataSet = 'SRR8994378_S47D';
trFilePath = '..\Data\TranscriptomicsData.xlsx';
compareGeneExpressionLevels(sourceDataSet, targetDataSet, trFilePath)