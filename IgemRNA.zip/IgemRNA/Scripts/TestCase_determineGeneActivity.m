thApproach = 2; % 1-GT1; 2-LT1; 3-LT2
glower = 30;
gupper = 100;
trFilePath = '..\Data\TranscriptomicsData.xlsx';
determineGeneActivity(thApproach, glower, gupper, trFilePath);